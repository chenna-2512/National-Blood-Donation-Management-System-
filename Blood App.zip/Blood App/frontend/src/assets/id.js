export const id = {
    service_id : "service_013am7b",
    template_id : "template_3ugz6te",
    template_noid : "template_x25j7ak",
    public_key : "Wn5zFMRojuZAe7l9i",
}