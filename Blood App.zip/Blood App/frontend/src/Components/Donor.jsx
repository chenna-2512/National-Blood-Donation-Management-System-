import Footer1 from "../Utilities/Footer1"
import Header2 from "../Utilities/Header2"
import Heading from "../Utilities/Heading"

const Donor = () => {
  return (
    <>
      <Heading/>
      <Header2/>
      <Footer1/>
    </>
  )
}

export default Donor
