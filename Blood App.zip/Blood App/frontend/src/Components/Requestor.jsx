import Footer1 from "../Utilities/Footer1"
import Header3 from "../Utilities/Header3"
import Heading from "../Utilities/Heading"

const Requestor = () => {
  return (
    <>
      <Heading/>
      <Header3/>
      <div>
      </div>
      <Footer1/>
    </>
  )
}

export default Requestor
