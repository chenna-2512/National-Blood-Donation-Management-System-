// import React from 'react'

const BBDetails = () => {
  return (
    <div>
      hi
    </div>
  )
}

export default BBDetails
