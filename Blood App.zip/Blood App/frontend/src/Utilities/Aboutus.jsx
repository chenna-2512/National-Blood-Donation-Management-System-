// import React from 'react'
import Heading from "../Utilities/Heading"
import Footer1 from "../Utilities/Footer1"

const Aboutus = () => {
  return (
    <div>
      <Heading/>
      <Footer1/>
    </div>
  )
}

export default Aboutus
